package view.ihm;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class PanneauTransport extends JPanel {

	public PanneauTransport() {
		super();
		this.setBackground(Color.CYAN);


		Object[][] data = { { "Cloclo", "GILLET", "Clotilde", "****", "clogillet@hotmail.fr", "histoire", null, null },
				{ "PapiMaxou", "GILARDIN", "Maximilien", "********", "maxou@gmail.com", null, null, null } };

		String title[] = { "username", "name", "surname", "password", "mail", "interest1", "interest2", "interest3" };
		JTable tableau = new JTable(data, title);
		// setCellEditor(new DeleteButtonEditor());
		this.add(new JScrollPane(tableau));

		JPanel boutons = new JPanel();

		boutons.add(new JButton("ajouter"));
		boutons.add(new JButton("supprimer"));

		this.add(boutons, BorderLayout.SOUTH);

	}

	private class AddAction extends AbstractAction {

		@Override
		public void actionPerformed(ActionEvent e) {

		}
	}
}
