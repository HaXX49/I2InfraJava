package view.ihm;

import java.awt.CardLayout;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JToggleButton;

import controller.actions.ActionPanelLieux;
import controller.actions.ActionPanelTransport;
import controller.actions.ActionPanelUsers;

public class PanneauChoix extends JPanel {

	private ButtonGroup monGroupeDeBoutons = new ButtonGroup();
	private JToggleButton users, lieux, transport;
	private JFrame maFenetre;

	public PanneauChoix(JFrame laFenetre, JPanel content, CardLayout maCardLayout) {
		this.setMaFenetre(laFenetre);

		this.setUsers(new JToggleButton(new ActionPanelUsers(this, maCardLayout, content)));

		this.setLieux(new JToggleButton(new ActionPanelLieux(maCardLayout, content)));

		this.setTransport(new JToggleButton(new ActionPanelTransport(maCardLayout, content)));

		this.monGroupeDeBoutons.add(lieux);
		this.monGroupeDeBoutons.add(users);
		this.monGroupeDeBoutons.add(transport);

		this.setLayout(new BoxLayout(this, BoxLayout.LINE_AXIS));
		this.add(this.getUsers());
		this.add(this.getLieux());
		this.add(this.getTransport());
	}

	public JToggleButton getUsers() {
		return users;
	}

	public void setUsers(JToggleButton users) {
		this.users = users;
	}

	public JToggleButton getLieux() {
		return lieux;
	}

	public void setLieux(JToggleButton lieux) {
		this.lieux = lieux;
	}

	public JToggleButton getTransport() {
		return transport;
	}

	public void setTransport(JToggleButton transport) {
		this.transport = transport;
	}

	public JFrame getMaFenetre() {
		return maFenetre;
	}

	public void setMaFenetre(JFrame maFenetre) {
		this.maFenetre = maFenetre;
	}

	public ButtonGroup getMonGroupeDeBoutons() {
		return monGroupeDeBoutons;
	}

	public void setMonGroupeDeBoutons(ButtonGroup monGroupeDeBoutons) {
		this.monGroupeDeBoutons = monGroupeDeBoutons;
	}
}
