package view.ihm;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.xml.crypto.Data;

public class PanneauUsers extends JPanel {

	private JPanel b4 = new JPanel();
	// On positionne maintenant ces trois lignes en colonne

	public PanneauUsers() {
		super();
		this.setBackground(Color.ORANGE);
		//////////////////////////////////////////////////////
		ArrayList<Object[]> myList = new ArrayList<Object[]>();
		try {
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver O.K.");

			String url = "jdbc:postgresql://192.168.4.151:5432/infra";
			String user = "postgres";
			String password = "SteinsGate";
			Connection conn = DriverManager.getConnection(url, user, password);
			System.out.println("Connexion effective !");
			conn.setAutoCommit(false);

			Statement state = conn.createStatement();
			// L'objet ResultSet contient le r�sultat de la requ�te SQL
			ResultSet result = state.executeQuery("SELECT * FROM place");
			// On r�cup�re les MetaData
			ResultSetMetaData resultMeta = result.getMetaData();

			System.out.println("\n**********************************");
			// On affiche le nom des colonnes
			for (int i = 1; i <= resultMeta.getColumnCount(); i++)
				System.out.print("\t" + resultMeta.getColumnName(i).toUpperCase() + "\t *");
			ArrayList<String> data2 = new ArrayList<String>();
			System.out.println("\n**********************************");

			while (result.next()) {
				for (int i = 1; i <= resultMeta.getColumnCount(); i++) {
					if (result.getObject(i) != null) {
						System.out.print("\t" + result.getObject(i).toString() + "\t |");
						data2.add(result.getObject(i).toString());
						System.out.println("\n---------------------------------");
					} else {
						data2.add("");
					}
					Object[] data = data2.toArray();
					myList.add(data);
				}
			}

			result.close();
			state.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		/////////////////////////////////////////////////////////////
		//Object[][] data3= (Object[][]) myList.toArray();
		
		Object[][] data3 = { { "1", "Martin", "Lucie", "lucmart", "magie" } };
		
		String title[] = { "id", "lastname", "firstname", "email", "password" };
		JTable tableau = new JTable(data3, title);
		// setCellEditor(new DeleteButtonEditor());
		this.add(new JScrollPane(tableau));

		JPanel boutons = new JPanel();

		boutons.add(new JButton("ajouter"));
		boutons.add(new JButton("supprimer"));

		this.add(boutons, BorderLayout.SOUTH);

	}

	// private class AddAction extends AbstractAction{

	// @Override
	// public void actionPerformed(ActionEvent e) {
	//
	// }

	//

}
