package view.ihm;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class PanneauAction extends JPanel{

	private JButton delete, new2, save;
	private JFrame maFenetre;
	
	public PanneauAction(JFrame laFenetre) {
		this.setMaFenetre(laFenetre);
		this.setDelete(new JButton("delete"));
		this.setNew2(new JButton("new"));
		this.setSave(new JButton("save"));
		
		this.setLayout(new BoxLayout(this, BoxLayout.LINE_AXIS));
		this.add(this.getDelete());
		this.add(this.getNew2());
		this.add(this.getSave());
	}

	public JFrame getMaFenetre() {
		return maFenetre;
	}

	public void setMaFenetre(JFrame maFenetre) {
		this.maFenetre = maFenetre;
	}

	public JButton getDelete() {
		return delete;
	}

	public void setDelete(JButton delete) {
		this.delete = delete;
	}

	public JButton getNew2() {
		return new2;
	}

	public void setNew2(JButton new2) {
		this.new2 = new2;
	}

	public JButton getSave() {
		return save;
	}

	public void setSave(JButton save) {
		this.save = save;
	}
	
}
