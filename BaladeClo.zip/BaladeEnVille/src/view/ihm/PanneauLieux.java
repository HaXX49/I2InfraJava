package view.ihm;

import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class PanneauLieux extends JPanel{

	public PanneauLieux() {
		this.setBackground(Color.RED);
		
		Object[][] data = {
				{ "Ch�teau d'Angers", "9.5", "10:00", "4.5", "hisoire","17"},
				{"Coll�giale Saint-Martin","4","13:00","4.5","histoire","18"}
		};
		
		String title[] = {"name","prices","openingTime","score","interest","tram"};
		
		JTable tableau = new JTable(data,title);
		
		this.add(new JScrollPane(tableau));
		
	}
}
