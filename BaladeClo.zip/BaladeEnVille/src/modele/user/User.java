package modele.user;

import java.util.ArrayList;
import java.util.List;

/**
 * User class 
 */
public class User {

    /**
     * Attributs
     */
	public static final String NONRENSEIGNE = "nr";
    public String username;
    public String name;
    public String surname;
    public String password;
    public String mailAddress;
    public List<String> interests = new ArrayList<String>(); 
  //public List<User> users = new ArrayList<User>(); �a va pas poser probl�me de faire une liste de User dans la classe User ?

    /**
     * Constructor
     * 
     * @param name the name
     * @param surname the surname
     * @param username the username 
     * @param password the password
     * @param mailAddress the mailAddress
     */
    public User(String name, String surname, String username, String password, String mailAddress){
        this.username = username;
        this.password = password;
        this.name = name;
        this.surname = surname;
        this.mailAddress = mailAddress;
    }
    /**
     * Constructor
     * 
     * @param username
     * @param password
     */
    public User(String username, String password) {
    	this.name = NONRENSEIGNE;
    	this.surname = NONRENSEIGNE;
    	this.username = username;
    	this.password = password;
    	this.mailAddress = NONRENSEIGNE;
    }
    /**
     * 
     * @return the name
     */
    public String getName() {
		return name;
	}
    /**
     * 
     * @param name the name to set
     */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * 
	 * @return the surname
	 */
	public String getSurname() {
		return surname;
	}
	/**
	 * 
	 * @param surname the surname to set
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}
	/**
	 * 
	 * @return the mailAddress
	 */
	public String getMailAddress() {
		return mailAddress;
	}
	/**
	 * 
	 * @param mailAddress the mailAddress to set
	 */
	public void setMailAddress(String mailAddress) {
		this.mailAddress = mailAddress;
	}

	/**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Generates a representation of the user
     */
    @Override
    public String toString() {
        return "User : " + this.getUsername() + " - Password : " + this.password;
    }

    /**
     * @return list of interests
     */
    public List<String> getInterests() {
        return interests;
    }

}