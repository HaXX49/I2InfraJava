import java.awt.BorderLayout;


import java.awt.CardLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import view.ihm.PanneauAction;
import view.ihm.PanneauChoix;
import view.ihm.PanneauLieux;
import view.ihm.PanneauTransport;
import view.ihm.PanneauUsers;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JFrame fenetre = new JFrame();
		
		fenetre.setTitle("Ma balade en ville");
	    fenetre.setSize(600, 600);
	    fenetre.setLocationRelativeTo(null);
	    fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    
	    
	    CardLayout cl = new CardLayout();
	    String[] listContent = {"users", "transport", "lieux"};
	    JPanel content = new JPanel();
	    
	    content.setBackground(Color.black);	    
	    
///////////////////////////////////////////////////////////////////////////
	    
	    PanneauUsers card1 = new PanneauUsers();
	    
	    PanneauTransport card2 = new PanneauTransport();
	    
	    PanneauLieux card3 = new PanneauLieux();
	    
	    
	    //On d�finit le layout
	    content.setLayout(cl);
	    //On ajoute les cartes � la pile avec un nom pour les retrouver
	    content.add(card1, listContent[0]);
	    content.add(card2, listContent[1]);
	    content.add(card3, listContent[2]);
	    

	    /////////////////////////////////////////////////////////////////

		
	    PanneauChoix monPanneauChoix = new PanneauChoix(fenetre,content,cl);
	    
	    fenetre.add(monPanneauChoix,BorderLayout.SOUTH);
	    
	    fenetre.add(content);
	    
	    fenetre.setVisible(true);
	    
	}

}
