package model;

public class Tramway {

}
