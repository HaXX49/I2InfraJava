package model;

public class Route {

}
