package model;

public class Waypoint {

}
