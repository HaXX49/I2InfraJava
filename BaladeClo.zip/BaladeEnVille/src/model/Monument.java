package model;

public class Monument {

}
