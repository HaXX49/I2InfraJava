package controller.actions;

public class Delete {

}
