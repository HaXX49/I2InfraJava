package controller.actions;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JPanel;

public class ActionPanelLieux extends AbstractAction{

	private JPanel content;
	private CardLayout maCardLayout;
	
	public ActionPanelLieux(CardLayout maCardLayout, JPanel content) {
		super("lieux");
		this.content = content;
		this.maCardLayout = maCardLayout;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		maCardLayout.show(content, "lieux");
	}
}
