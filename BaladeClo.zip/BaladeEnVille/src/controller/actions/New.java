package controller.actions;

public class New {

}
