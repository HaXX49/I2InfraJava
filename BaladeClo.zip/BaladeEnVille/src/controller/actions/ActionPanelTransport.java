package controller.actions;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JPanel;

public class ActionPanelTransport extends AbstractAction{

	private JPanel content;
	private CardLayout maCardLayout;
	
	public ActionPanelTransport(CardLayout maCardLayout, JPanel content) {
		super("transport");
		this.content = content;
		this.maCardLayout = maCardLayout;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		maCardLayout.show(content, "transport");
	}

}
