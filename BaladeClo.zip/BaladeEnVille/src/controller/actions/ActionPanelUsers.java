package controller.actions;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JPanel;

import view.ihm.PanneauChoix;
import view.ihm.PanneauUsers;

public class ActionPanelUsers extends AbstractAction{

	private PanneauChoix monPanneauChoix;
	private PanneauUsers monPanneauUsers;
	private CardLayout maCardLayout;
	private JPanel content;
	
	public ActionPanelUsers(PanneauChoix monPanneauChoix, CardLayout maCardLayout, JPanel content) {
		super("users");
		this.monPanneauChoix = monPanneauChoix;
		this.maCardLayout = maCardLayout;
		this.content = content;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		maCardLayout.show(content, "users");
	}

	
}
